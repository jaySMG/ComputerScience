package com.example.inventorymanagementapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// Handles all database operations for the app
class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "InventoryDB", null, 1) {

    // Create tables when database is first created
    override fun onCreate(db: SQLiteDatabase) {

        // Table for storing user login credentials
        db.execSQL(
            "CREATE TABLE users (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "username TEXT, " +
                    "password TEXT)"
        )

        // Table for storing inventory items
        db.execSQL(
            "CREATE TABLE inventory (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "name TEXT, " +
                    "quantity INTEGER)"
        )
    }

    // Runs when database version changes
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS users")
        db.execSQL("DROP TABLE IF EXISTS inventory")
        onCreate(db)
    }

    // ---------------- USER FUNCTIONS ----------------

    // Register a new user
    fun registerUser(username: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues()

        values.put("username", username)
        values.put("password", password)

        val result = db.insert("users", null, values)
        return result != -1L
    }

    // Check login credentials
    fun loginUser(username: String, password: String): Boolean {
        val db = readableDatabase

        val cursor = db.rawQuery(
            "SELECT * FROM users WHERE username=? AND password=?",
            arrayOf(username, password)
        )

        val exists = cursor.count > 0
        cursor.close()

        return exists
    }

    // ---------------- INVENTORY CRUD ----------------

    // CREATE: Add new item
    fun addItem(name: String, quantity: Int) {
        val db = writableDatabase
        val values = ContentValues()

        values.put("name", name)
        values.put("quantity", quantity)

        db.insert("inventory", null, values)
    }

    // READ: Get all items (includes ID)
    fun getItems(): List<Triple<Int, String, Int>> {
        val list = mutableListOf<Triple<Int, String, Int>>()
        val db = readableDatabase

        val cursor = db.rawQuery("SELECT * FROM inventory", null)

        while (cursor.moveToNext()) {
            val id = cursor.getInt(0)       // PRIMARY KEY
            val name = cursor.getString(1) // ITEM NAME
            val qty = cursor.getInt(2)     // QUANTITY

            // Triple = (id, name, quantity)
            list.add(Triple(id, name, qty))
        }

        cursor.close()
        return list
    }

    // UPDATE: Modify an existing item
    fun updateItem(id: Int, name: String, quantity: Int) {
        val db = writableDatabase
        val values = ContentValues()

        values.put("name", name)
        values.put("quantity", quantity)

        db.update("inventory", values, "id=?", arrayOf(id.toString()))
    }

    // DELETE: Remove an item
    fun deleteItem(id: Int) {
        val db = writableDatabase
        db.delete("inventory", "id=?", arrayOf(id.toString()))
    }
}