package com.example.inventorymanagementapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.inventorymanagementapp.ui.theme.InventoryManagementAppTheme

// Represents a single inventory item with a unique ID, name, and quantity
data class InventoryItem(val id: Int, val name: String, var quantity: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            InventoryManagementAppTheme {
                AppNavigator()
            }
        }
    }
}

// ─── SMS HELPER ────────────────────────────────────────────────
/**
 * Attempts to send an SMS alert to the given phone number.
 * Called only when quantity reaches zero AND SMS permission is granted.
 * If permission is denied, this function is never invoked and the app
 * continues to function normally without SMS.
 *
 * @param context    App context needed to check permission status
 * @param phoneNumber Destination number for the low-stock alert
 * @param itemName   Name of the item that has run out of stock
 */
fun sendLowStockSms(context: android.content.Context, phoneNumber: String, itemName: String) {
    // Double-check permission at send time — user may have revoked it in settings
    val hasPermission = ContextCompat.checkSelfPermission(
        context, Manifest.permission.SEND_SMS
    ) == PackageManager.PERMISSION_GRANTED

    if (hasPermission) {
        try {
            val smsManager = SmsManager.getDefault()
            val message = "⚠️ Low Stock Alert: '$itemName' has reached zero. Please restock."
            smsManager.sendTextMessage(
                phoneNumber,  // recipient
                null,         // service centre (null = default)
                message,      // alert body
                null,         // sent pending intent
                null          // delivered pending intent
            )
        } catch (e: Exception) {
            // Log silently — SMS failure should not crash the app
            e.printStackTrace()
        }
    }
    // If permission is denied, simply do nothing and the app continues normally
}

// ─── NAVIGATION ────────────────────────────────────────────────
// Controls which screen is currently visible to the user
@Composable
fun AppNavigator() {
    var currentScreen by remember { mutableStateOf("login") }

    when (currentScreen) {
        "login"     -> LoginScreen(onLoginSuccess = { currentScreen = "inventory" })
        "inventory" -> InventoryScreen(onNavigateSms = { currentScreen = "sms" })
        "sms"       -> SmsPermissionScreen(onDone = { currentScreen = "inventory" })
    }
}

// ─── SCREEN 1: LOGIN ──────────────────────────────────────────
@Composable
fun LoginScreen(onLoginSuccess: () -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var message  by remember { mutableStateOf("") }

    val context  = LocalContext.current
    val dbHelper = DatabaseHelper(context)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1B2A3B))
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // App title / branding
        Text(
            text = "WarehouseTrack",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Inventory Management System",
            fontSize = 14.sp,
            color = Color(0xFF90CAF9)
        )

        Spacer(modifier = Modifier.height(40.dp))

        // Login / registration card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(24.dp)) {

                Text(
                    text = "Sign In",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1B2A3B)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Username input
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Username") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Password input — characters are hidden for security
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Login button — validates credentials against the database
                Button(
                    onClick = {
                        if (username.isNotBlank() && password.isNotBlank()) {
                            val success = dbHelper.loginUser(username, password)
                            if (success) {
                                message = "Login successful"
                                onLoginSuccess()
                            } else {
                                message = "Invalid username or password"
                            }
                        } else {
                            message = "Please enter username and password"
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0))
                ) {
                    Text("Login", color = Color.White)
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Registration button — creates a new account in the database
                OutlinedButton(
                    onClick = {
                        if (username.isNotBlank() && password.isNotBlank()) {
                            val success = dbHelper.registerUser(username, password)
                            message = if (success) {
                                username = ""
                                password = ""
                                "Account created successfully"
                            } else {
                                "Registration failed"
                            }
                        } else {
                            message = "Please fill in all fields"
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Create New Account", color = Color(0xFF1565C0))
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Displays success or error feedback to the user
                Text(
                    text = message,
                    color = Color.Red,
                    fontSize = 14.sp
                )
            }
        }
    }
}

// ─── SCREEN 2: INVENTORY GRID ──────────────────────────────────
@Composable
fun InventoryScreen(onNavigateSms: () -> Unit) {

    val context  = LocalContext.current
    val dbHelper = DatabaseHelper(context)

    // Reactive list — recomposed whenever items are added, updated, or deleted
    var items        by remember { mutableStateOf(dbHelper.getItems()) }
    var showAddPanel by remember { mutableStateOf(false) }
    var newItemName  by remember { mutableStateOf("") }
    var newItemQty   by remember { mutableStateOf("") }

    // Check SMS permission status so we know whether to send alerts
    val smsPermissionGranted = ContextCompat.checkSelfPermission(
        context, Manifest.permission.SEND_SMS
    ) == PackageManager.PERMISSION_GRANTED

    // Phone number that receives low-stock SMS alerts
    // In production this would come from user settings / a stored preference ideally.
    val alertPhoneNumber = "5551234567"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F6F8))
    ) {

        // ── Top bar ──────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1565C0))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Inventory",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )

            // Navigate to SMS settings screen
            Button(
                onClick = { onNavigateSms() },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White)
            ) {
                Text("SMS Settings", color = Color(0xFF1565C0), fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Toggle the add-item panel
            Button(
                onClick = { showAddPanel = !showAddPanel },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White)
            ) {
                Text("+ Add Item", color = Color(0xFF1565C0), fontSize = 12.sp)
            }
        }

        // ── Column headers ────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1B2A3B))
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Text("Item Name", modifier = Modifier.weight(2f), color = Color(0xFF90CAF9))
            Text("Qty",       modifier = Modifier.weight(1f), color = Color(0xFF90CAF9))
            Text("Upd",       modifier = Modifier.width(48.dp), color = Color(0xFF90CAF9))
            Text("Del",       modifier = Modifier.width(48.dp), color = Color(0xFF90CAF9))
        }

        // ── Inventory rows (loaded from SQLite database) ───────
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(8.dp)
        ) {
            items(items.size) { index ->

                val item = items[index]
                val id   = item.first
                val name = item.second
                val qty  = item.third

                // Row turns red when quantity is zero to flag low stock visually
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (qty == 0) Color(0xFFFFEBEE) else Color.White
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Item name
                        Text(name, modifier = Modifier.weight(2f))

                        // Quantity — shown in red when zero
                        Text(
                            "$qty",
                            modifier = Modifier.weight(1f),
                            color = if (qty == 0) Color.Red else Color.Black
                        )

                        // Increment quantity by 1
                        IconButton(
                            onClick = {
                                val newQty = qty + 1
                                dbHelper.updateItem(id, name, newQty)
                                items = dbHelper.getItems()
                            },
                            modifier = Modifier.width(48.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Increase quantity")
                        }

                        // Delete item from database
                        IconButton(
                            onClick = {
                                dbHelper.deleteItem(id)
                                items = dbHelper.getItems()
                            },
                            modifier = Modifier.width(48.dp)
                        ) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = "Delete item",
                                tint = Color.Red
                            )
                        }
                    }
                }
            }
        } //

        // ── Add item panel ─────────────────────────────────────
        if (showAddPanel) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                elevation = CardDefaults.cardElevation(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {

                    Text("Add New Item", fontWeight = FontWeight.Bold)

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = newItemName,
                        onValueChange = { newItemName = it },
                        label = { Text("Item Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = newItemQty,
                        onValueChange = { newItemQty = it },
                        label = { Text("Quantity") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Confirm button — saves item to database, then checks if
                    // quantity is already zero and fires an SMS alert if needed
                    Button(
                        onClick = {
                            if (newItemName.isNotBlank()) {
                                val qty = newItemQty.toIntOrNull() ?: 0

                                dbHelper.addItem(newItemName, qty)
                                items = dbHelper.getItems()

                                // Trigger low-stock SMS if item was added with zero qty
                                // and the user has granted SMS permission
                                if (qty == 0 && smsPermissionGranted) {
                                    sendLowStockSms(context, alertPhoneNumber, newItemName)
                                }

                                // Reset form fields and hide the panel
                                newItemName  = ""
                                newItemQty   = ""
                                showAddPanel = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0))
                    ) {
                        Text("Confirm Add", color = Color.White)
                    }
                }
            }
        }

    } //
} //

// ─── SCREEN 3: SMS PERMISSION ──────────────────────────────────
/**
 * Requests SEND_SMS permission from the user.
 * - If granted: SMS alerts will fire when any item quantity reaches zero.
 * - If denied:  The app continues to work fully; SMS alerts are simply skipped.
 */
@Composable
fun SmsPermissionScreen(onDone: () -> Unit) {
    val context = LocalContext.current

    // Check current permission state so the UI reflects reality on first load
    var permissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    // System permission dialog launcher — updates state with the user's response
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        // isGranted = true  → user allowed SMS, alerts are now active
        // isGranted = false → user denied SMS, app continues without alerts
        permissionGranted = isGranted
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1B2A3B))
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("📦", fontSize = 64.sp)

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Low Stock Alerts",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Explain to the user why SMS permission is needed
        Text(
            text = "WarehouseTrack can send you an SMS when any item reaches zero " +
                    "quantity so you can restock immediately.",
            fontSize = 15.sp,
            color = Color(0xFFB0BEC5),
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Live permission status indicator — updates after user responds to dialog
        Text(
            text = if (permissionGranted)
                "✅  SMS Permission: Granted"
            else
                "❌  SMS Permission: Not Granted",
            color = if (permissionGranted) Color(0xFFA5D6A7) else Color(0xFFEF9A9A),
            fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Launches the system permission dialog; disabled once permission is granted
        Button(
            onClick = {
                permissionLauncher.launch(Manifest.permission.SEND_SMS)
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0)),
            enabled = !permissionGranted   // hide affordance once already granted
        ) {
            Text("Enable SMS Notifications", color = Color.White)
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Skip option — user explicitly declines; app works without SMS feature
        OutlinedButton(
            onClick = { onDone() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Skip — No Notifications", color = Color(0xFF90CAF9))
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Reassure the user that denying SMS does not break core functionality
        Text(
            text = "The app will still function fully without SMS access.",
            fontSize = 12.sp,
            color = Color(0xFF607D8B)
        )
    }
} //